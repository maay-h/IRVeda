import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { ArrowRight, Flower2, HeartPulse, Sparkles } from 'lucide-react'

const services = [
  {
    category: "Women's Wellness",
    color: 'rgba(201,168,76,0.08)',
    accent: 'var(--color-gold)',
    icon: Flower2,
    items: [
      { name: 'PCOD', desc: 'Personalized Ayurvedic support for PCOD management through lifestyle and wellness guidance.' },
      { name: 'PCOS', desc: 'Holistic approach to PCOS with individualized care and dietary recommendations.' },
      { name: "Women's Fertility Concerns", desc: 'Supportive Ayurvedic consultation for women exploring fertility wellness options.' },
      { name: "Women's Health", desc: 'Comprehensive care addressing various aspects of women\'s overall health and wellbeing.' },
    ],
  },
  {
    category: 'Health & Wellness',
    color: 'rgba(74,124,89,0.06)',
    accent: 'var(--color-earth)',
    icon: HeartPulse,
    items: [
      { name: 'Body Detox', desc: 'Signature Ayurvedic detoxification program personalized to your constitution.' },
      { name: 'Psoriasis Support', desc: 'Traditional Ayurvedic approach to skin health and psoriasis wellness.' },
      { name: 'Thyroid Wellness', desc: 'Personalized guidance for thyroid-related health concerns through Ayurveda.' },
      { name: 'Diabetes Wellness', desc: 'Ayurvedic lifestyle and dietary support for diabetes-related health management.' },
      { name: 'Kidney & Gallbladder', desc: 'Supportive Ayurvedic consultation for stone-related health concerns.' },
      { name: 'Allergy Support', desc: 'Individualized Ayurvedic approach to managing allergic conditions.' },
    ],
  },
  {
    category: 'Specialized Services',
    color: 'rgba(139,107,74,0.06)',
    accent: 'var(--color-brown)',
    icon: Sparkles,
    items: [
      { name: 'Suvarna Prasha', desc: 'Traditional Ayurvedic formulation consultation, suitable for various age groups.' },
      { name: 'Bone Health', desc: 'Personalized Ayurvedic support for bone and joint health and wellness.' },
      { name: 'Customized Bone Health Medicines', desc: 'Individually formulated bone health preparations based on consultation.' },
      { name: 'Personalized Ayurvedic Medicines', desc: 'Bespoke Ayurvedic formulations prepared after thorough consultation.' },
    ],
  },
]

export default function Services() {
  return (
    <section style={{ background: 'var(--color-cream-dark)', padding: 'clamp(3.5rem, 6vw, 6rem) 0', overflow: 'hidden' }}>
      <div className="section-wrapper">
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div className="section-tag" style={{ justifyContent: 'center', marginBottom: '0.75rem' }}>Our Services</div>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 'clamp(1.75rem, 3.5vw, 2.75rem)', fontWeight: 700, color: 'var(--color-forest)', marginBottom: '0.75rem' }}>
            Treatments & Health Concerns
          </h2>
          <p style={{ color: 'var(--color-text-muted)', maxWidth: '540px', margin: '0 auto', fontSize: '0.9375rem', lineHeight: 1.7 }}>
            All treatment recommendations are individualized based on your consultation. We follow responsible Ayurvedic care without making guaranteed outcome claims.
          </p>
        </div>

        {services.map((group, gi) => {
          const GroupIcon = group.icon
          return (
            <div key={gi} style={{ marginBottom: '2.75rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.25rem' }}>
                <div style={{
                  width: '34px', height: '34px', borderRadius: '10px',
                  background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  border: '1px solid var(--color-beige)',
                  color: group.accent,
                  flexShrink: 0,
                }}>
                  <GroupIcon size={18} />
                </div>
                <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.375rem', fontWeight: 600, color: 'var(--color-forest)' }}>{group.category}</h3>
                <div style={{ flex: 1, height: '1px', background: 'var(--color-beige)' }} />
              </div>

              <div className="services-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(min(100%, 240px), 1fr))', gap: '1rem' }}>
                {group.items.map((item, ii) => (
                  <motion.div
                    key={ii}
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: ii * 0.05 }}
                    className="card"
                    style={{ padding: '1.25rem', background: 'white' }}
                  >
                    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '0.5rem', gap: '0.5rem' }}>
                      <h4 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.0625rem', fontWeight: 600, color: 'var(--color-forest)', lineHeight: 1.3 }}>
                        {item.name}
                      </h4>
                      <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: group.accent, flexShrink: 0, marginTop: '0.375rem' }} />
                    </div>
                    <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', lineHeight: 1.55, marginBottom: '1rem' }}>
                      {item.desc}
                    </p>
                    <Link
                      to="/book-appointment"
                      style={{
                        display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
                        fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-earth)',
                        textDecoration: 'none', transition: 'gap 0.2s',
                      }}
                    >
                      Book Consultation <ArrowRight size={13} />
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
          )
        })}

        <div style={{ textAlign: 'center', marginTop: '1.5rem' }}>
          <Link to="/treatments" className="btn-secondary" style={{ width: '100%', maxWidth: '280px' }}>
            View All Treatments <ArrowRight size={16} />
          </Link>
        </div>
      </div>

      <style>{`
        @media (max-width: 580px) {
          .services-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  )
}
